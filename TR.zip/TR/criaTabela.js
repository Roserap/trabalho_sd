const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));

let conexao = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
});

conexao.connect(function (erro) {
  if (erro) {
    throw erro;
  } else {
    console.log('Conexão estabelecida com sucesso!');
  }
});


app.post('/criar-tabela', (req, res) => {
    const nomeTabela = req.body.nomeTabela;
    const colunas = req.body.colunas;

    const sql = `CREATE TABLE \`${nomeTabela}\` (${colunas})`;
    conexao.query(sql, (err, result) => {
        if (err) {
            console.error('Erro ao criar a tabela: ' + err.message);
            return res.status(500).send('Erro ao criar a tabela: ' + err.message);
        }
        res.send(`Tabela "${nomeTabela}" criada com sucesso!`);
    });
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});