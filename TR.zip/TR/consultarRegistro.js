const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');

const app = express();

app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'agenda'
});

conexao.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados: ' + err.stack);
        return;
    }
    console.log('Conectado ao banco de dados como ID ' + conexao.threadId);
});

app.get('/listar-tabelas', (req, res) => {
    const sql = "SHOW TABLES";

    conexao.query(sql, (err, results) => {
        if (err) {
            console.error('Erro ao listar tabelas: ' + err.message);
            return res.status(500).send('Erro ao listar tabelas');
        }
        
        const tabelas = results.map(row => Object.values(row)[0]);
        res.json(tabelas);
    });
});

app.get('/listar-registros', (req, res) => {
    const tabela = req.query.tabela;
    if (!tabela) {
        return res.status(400).send('Tabela não especificada');
    }

    const sql = `SELECT * FROM \`${tabela}\``;

    conexao.query(sql, (err, results) => {
        if (err) {
            console.error('Erro ao listar registros: ' + err.message);
            return res.status(500).send('Erro ao listar registros');
        }
        res.json(results);
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});