const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));

// Configuração da conexão com o MySQL
let conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Usuário padrão do XAMPP
    password: '', // Senha padrão do XAMPP (geralmente vazia)
    port: 3306, // Porta padrão do MySQL
});

// Conectar ao MySQL
conexao.connect(function (erro) {
    if (erro) {
        throw erro;
    } else {
        console.log('Conexão estabelecida com sucesso!');
    }
});

// Rota para listar bancos de dados
app.get('/listar-bancos', (req, res) => {
    conexao.query('SHOW DATABASES', (err, results) => {
        if (err) {
            console.error('Erro ao listar bancos de dados: ' + err.message);
            return res.status(500).send('Erro ao listar bancos de dados');
        }
        res.json(results); // Retorna a lista de bancos de dados como JSON
    });
});

// Rota para criar a tabela
app.post('/criar-tabela', (req, res) => {
    const nomeTabela = req.body.nomeTabela; // Nome da tabela fornecido pelo usuário
    const banco = req.body.banco; // Banco de dados selecionado
    const campos = [];

    // Montar a definição dos campos
    for (let i = 1; i <= 3; i++) {
        const campoNome = req.body[`campo${i}Nome`];
        const campoTipo = req.body[`campo${i}Tipo`];
        const campoTamanho = req.body[`campo${i}Tamanho`];

        if (campoNome && campoTipo) {
            campos.push(`${campoNome} ${campoTipo}`);
        }
    }

    // Criar a tabela
    const sql = `CREATE TABLE \`${nomeTabela}\` (${campos.join(', ')})`; // Use crase para evitar problemas com nomes
    conexao.query(`USE \`${banco}\`;`, (err) => {
        if (err) {
            console.error('Erro ao selecionar o banco de dados: ' + err.message);
            return res.status(500).send('Erro ao selecionar o banco de dados: ' + err.message);
        }

        conexao.query(sql, (err, result) => {
            if (err) {
                console.error('Erro ao criar a tabela: ' + err.message);
                return res.status(500).send('Erro ao criar a tabela: ' + err.message);
            }
            res.send(`Tabela "${nomeTabela}" criada com sucesso!`);
        });
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});