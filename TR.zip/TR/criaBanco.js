const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;


app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));

let conexao = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
});

conexao.connect(function (erro) {
  if (erro) {
    throw erro;
  } else {
    console.log('Conexão estabelecida com sucesso!');
  }
});

app.post('/', (req, res) => {
  const dbName = req.body.seunome;
  
  const sql = `CREATE DATABASE \`${dbName}\``;
  conexao.query(sql, (err, result) => {
    if (err) {
      console.error('Erro ao criar o banco de dados: ' + err.message);
      return res.status(500).send('Erro ao criar o banco de dados: ' + err.message);
    }
    res.send(`Banco de dados "${dbName}" criado com sucesso!`);
  });
});


app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});