const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');

const app = express();

app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'agenda'
});

conexao.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados: ' + err.stack);
        return;
    }
    console.log('Conectado ao banco de dados como ID ' + conexao.threadId);
});

app.get('/listar-tabelas', (req, res) => {
    const sql = "SHOW TABLES";

    conexao.query(sql, (err, results) => {
        if (err) {
            console.error('Erro ao listar tabelas: ' + err.message);
            return res.status(500).send('Erro ao listar tabelas');
        }
        
        const tabelas = results.map(row => Object.values(row)[0]);
        res.json(tabelas);
    });
});

app.post('/inserir-registro', (req, res) => {
    const tabela = req.body.tabela;
    const dados = {
        nome: req.body.Pessoa,
        email: req.body.email
    };

    const sql = `INSERT INTO \`${tabela}\` SET ?`;

    conexao.query(sql, dados, (err, result) => {
        if (err) {
            console.error('Erro ao inserir registro: ' + err.message);
            return res.status(500).send('Erro ao inserir registro');
        }
        res.send(`Registro inserido com sucesso na tabela "${tabela}"!`);
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});